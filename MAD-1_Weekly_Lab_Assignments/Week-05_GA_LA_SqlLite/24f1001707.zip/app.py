from flask import Flask , render_template , request , redirect , url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.sqlite3"

db = SQLAlchemy(app)
app.app_context().push()

class Student(db.Model):

    student_id = db.Column(db.Integer , primary_key = True , autoincrement = True )
    roll_number = db.Column(db.String() , unique = True , nullable = False)
    first_name = db.Column(db.String() , nullable = False)
    last_name = db.Column(db.String())
    courses = db.relationship("Course" , backref = "student" , secondary = "enrollments" , cascade="all , delete" , passive_deletes=True)
class Course(db.Model):

    course_id = db.Column(db.Integer , primary_key = True , autoincrement = True)
    course_code = db.Column(db.String() , unique = True , nullable = False)
    course_name = db.Column(db.String() , unique = True , nullable = False)
    course_description = db.Column(db.String())

class Enrollments(db.Model):

    enrollment_id = db.Column(db.Integer , primary_key = True , autoincrement = True )
    estudent_id = db.Column(db.Integer , db.ForeignKey("student.student_id" , ondelete='CASCADE') , nullable = False)
    ecourse_id = db.Column(db.Integer , db.ForeignKey("course.course_id" , ondelete='CASCADE') , nullable = False)


@app.route("/" , methods = ["GET", "POST"])
def home():

    stu_list = Student.query.all()
    return render_template("home.html" , stu = stu_list)

@app.route("/student/create" , methods = ["GET", "POST"])
def create_student():

    if request.method == "POST":
        r_no = request.form.get("roll")
        f_n = request.form.get("f_name")
        l_n = request.form.get("l_name")
        crs = request.form.getlist("courses")

        for i in Student.query.all():
            if(i.roll_number == r_no):
                return render_template("error.html")

        stud = Student(roll_number = r_no , first_name = f_n , last_name = l_n)
        db.session.add(stud)
        db.session.commit()

        if("course_1" in crs):
            c = Enrollments(estudent_id = stud.student_id , ecourse_id = 1)
            db.session.add(c)
            db.session.commit()
        
        if("course_2" in crs):
            c = Enrollments(estudent_id = stud.student_id , ecourse_id = 2)
            db.session.add(c)
            db.session.commit()

        if("course_3" in crs):
            c = Enrollments(estudent_id = stud.student_id , ecourse_id = 3)
            db.session.add(c)
            db.session.commit()

        if("course_4" in crs):
            c = Enrollments(estudent_id = stud.student_id , ecourse_id = 4)
            db.session.add(c)
            db.session.commit()

        return redirect('/')

    return render_template("add.html")
    


@app.route("/student/<int:id>")
def details(id):
    my_stu = Student.query.get(id)
    crss = my_stu.courses
    return render_template ("student.html" , det = my_stu , crss = crss)

@app.route("/student/<int:stu_id>/update" , methods = ["GET" , "POST"])
def update(stu_id):
    s = Student.query.get(stu_id)
    if request.method == "POST":
        f_n = request.form.get("f_name")
        l_n = request.form.get("l_name")
        crs = request.form.getlist("courses")

        s.first_name = f_n
        s.last_name = l_n
        db.session.commit()
        Enrollments.query.filter_by(estudent_id = stu_id).delete()
        db.session.commit()

        if("course_1" in crs):
            c = Enrollments(estudent_id = stu_id , ecourse_id = 1)
            db.session.add(c)
            db.session.commit()
        
        if("course_2" in crs):
            c = Enrollments(estudent_id = stu_id, ecourse_id = 2)
            db.session.add(c)
            db.session.commit()

        if("course_3" in crs):
            c = Enrollments(estudent_id = stu_id , ecourse_id = 3)
            db.session.add(c)
            db.session.commit()

        if("course_4" in crs):
            c = Enrollments(estudent_id = stu_id , ecourse_id = 4)
            db.session.add(c)
            db.session.commit()

        return redirect('/')
        
    return render_template("update.html" , student_id = stu_id , current_roll = s.roll_number , current_f_name = s.first_name , current_l_name = s.last_name)


@app.route("/student/<int:student_id>/delete")
def delete(student_id):
    stu = Student.query.get(student_id)
    db.session.delete(stu)
    Enrollments.query.filter_by(estudent_id = student_id).delete()
    db.session.commit()
    return redirect('/')


    

def main():
    app.run(debug = True)

if __name__ == "__main__":
    main()